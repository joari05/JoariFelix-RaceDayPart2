using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace RaceDay.Api.Security;
[AttributeUsage(AttributeTargets.Class|AttributeTargets.Method)]
public sealed class RequireSessionAttribute(params string[] roles) : Attribute, IAsyncAuthorizationFilter
{
 public Task OnAuthorizationAsync(AuthorizationFilterContext context)
 {
  var session=context.HttpContext.Session; var id=session.GetInt32("UserID"); var role=session.GetString("Role");
  if(id is null || string.IsNullOrWhiteSpace(role)){context.Result=new UnauthorizedObjectResult(new{message="Please log in first."});return Task.CompletedTask;}
  if(roles.Length>0 && !roles.Contains(role,StringComparer.OrdinalIgnoreCase)){context.Result=new ObjectResult(new{message="You do not have permission to access this resource."}){StatusCode=StatusCodes.Status403Forbidden};}
  return Task.CompletedTask;
 }
}
