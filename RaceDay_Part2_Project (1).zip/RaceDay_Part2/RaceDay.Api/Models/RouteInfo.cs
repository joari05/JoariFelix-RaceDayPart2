using System.ComponentModel.DataAnnotations;
namespace RaceDay.Api.Models;
public class RouteInfo { public int RouteID {get;set;} public int EventID {get;set;} [Required,MaxLength(150)] public string RouteName {get;set;}=""; public decimal DistanceKm {get;set;} [Required,MaxLength(200)] public string StartPoint {get;set;}=""; [Required,MaxLength(200)] public string FinishPoint {get;set;}=""; [MaxLength(1000)] public string? RouteInformation {get;set;} public Event? Event {get;set;} }
