using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;using RaceDay.Api.Data;using RaceDay.Api.Models;using RaceDay.Api.Security;
namespace RaceDay.Api.Controllers;
[ApiController,Route("api/events/{eventId:int}/route")]
public class RoutesController(RaceDayContext db):ControllerBase
{
 [HttpGet] public async Task<IActionResult> Get(int eventId){var r=await db.Routes.AsNoTracking().FirstOrDefaultAsync(x=>x.EventID==eventId);return r is null?NotFound():Ok(r);}
 [HttpPost,RequireSession("Organiser")] public async Task<IActionResult> Create(int eventId,RouteRequest r){if(r.DistanceKm<=0)return BadRequest(new{message="DistanceKm must be greater than zero."});var e=await db.Events.FindAsync(eventId);if(e is null)return NotFound();if(e.OrganiserID!=HttpContext.Session.GetInt32("UserID"))return Forbid();if(await db.Routes.AnyAsync(x=>x.EventID==eventId))return Conflict(new{message="This event already has a route."});var route=new RouteInfo{EventID=eventId,RouteName=r.RouteName,DistanceKm=r.DistanceKm,StartPoint=r.StartPoint,FinishPoint=r.FinishPoint,RouteInformation=r.RouteInformation};db.Routes.Add(route);await db.SaveChangesAsync();return CreatedAtAction(nameof(Get),new{eventId},route);}
 [HttpPut,RequireSession("Organiser")] public async Task<IActionResult> Update(int eventId,RouteRequest r){var route=await db.Routes.Include(x=>x.Event).FirstOrDefaultAsync(x=>x.EventID==eventId);if(route is null)return NotFound();if(route.Event!.OrganiserID!=HttpContext.Session.GetInt32("UserID"))return Forbid();if(r.DistanceKm<=0)return BadRequest();route.RouteName=r.RouteName;route.DistanceKm=r.DistanceKm;route.StartPoint=r.StartPoint;route.FinishPoint=r.FinishPoint;route.RouteInformation=r.RouteInformation;await db.SaveChangesAsync();return Ok(route);}
}
