using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;using RaceDay.Api.Data;using RaceDay.Api.Models;using RaceDay.Api.Security;
namespace RaceDay.Api.Controllers;
[ApiController,Route("api/events")]
public class EventsController(RaceDayContext db):ControllerBase
{
 [HttpGet,ProducesResponseType(200)] public async Task<IActionResult> GetAll()=>Ok(await db.Events.AsNoTracking().ToListAsync());
 [HttpGet("{eventId:int}")] public async Task<IActionResult> Get(int eventId){var e=await db.Events.AsNoTracking().Include(x=>x.Route).Include(x=>x.Categories).FirstOrDefaultAsync(x=>x.EventID==eventId);return e is null?NotFound():Ok(e);}
 [HttpPost,RequireSession("Organiser")] public async Task<IActionResult> Create(EventRequest r){if(!ValidType(r.EventType))return BadRequest(new{message="EventType must be Running, Walking or Cycling."});var e=new Event{EventName=r.EventName,EventType=r.EventType,Description=r.Description,EventDate=r.EventDate,StartTime=r.StartTime,Location=r.Location,OrganiserID=HttpContext.Session.GetInt32("UserID")!.Value};db.Events.Add(e);await db.SaveChangesAsync();return CreatedAtAction(nameof(Get),new{eventId=e.EventID},e);}
 [HttpPut("{eventId:int}"),RequireSession("Organiser")] public async Task<IActionResult> Update(int eventId,EventRequest r){var e=await db.Events.FindAsync(eventId);if(e is null)return NotFound();if(e.OrganiserID!=HttpContext.Session.GetInt32("UserID"))return Forbid();if(!ValidType(r.EventType))return BadRequest(new{message="Invalid event type."});e.EventName=r.EventName;e.EventType=r.EventType;e.Description=r.Description;e.EventDate=r.EventDate;e.StartTime=r.StartTime;e.Location=r.Location;await db.SaveChangesAsync();return Ok(e);}
 [HttpDelete("{eventId:int}"),RequireSession("Organiser")] public async Task<IActionResult> Delete(int eventId){var e=await db.Events.Include(x=>x.Enrolments).FirstOrDefaultAsync(x=>x.EventID==eventId);if(e is null)return NotFound();if(e.OrganiserID!=HttpContext.Session.GetInt32("UserID"))return Forbid();if(e.Enrolments.Count>0)return Conflict(new{message="Cannot delete an event with enrolments."});db.Events.Remove(e);await db.SaveChangesAsync();return NoContent();}
 internal static bool ValidType(string s)=>new[]{"Running","Walking","Cycling"}.Contains(s,StringComparer.OrdinalIgnoreCase);
}
