using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;using RaceDay.Api.Data;using RaceDay.Api.Models;using RaceDay.Api.Security;
namespace RaceDay.Api.Controllers;
[ApiController,Route("api/users"),RequireSession]
public class UsersController(RaceDayContext db):ControllerBase
{
 [HttpGet("me")] public async Task<IActionResult> Me(){var id=HttpContext.Session.GetInt32("UserID")!.Value;var u=await db.Users.FindAsync(id);return u is null?NotFound():Ok(new{u.UserID,u.FirstName,u.LastName,u.Email,u.Role,u.Phone,u.CreatedAt});}
 [HttpPut("me")] public async Task<IActionResult> Update(UpdateProfileRequest r){var id=HttpContext.Session.GetInt32("UserID")!.Value;var u=await db.Users.FindAsync(id);if(u is null)return NotFound();u.FirstName=r.FirstName.Trim();u.LastName=r.LastName.Trim();u.Phone=r.Phone;await db.SaveChangesAsync();return Ok(new{u.UserID,u.FirstName,u.LastName,u.Email,u.Role,u.Phone});}
}
