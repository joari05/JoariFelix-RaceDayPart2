using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore; using RaceDay.Api.Data; using RaceDay.Api.Models;
namespace RaceDay.Api.Controllers;
[ApiController,Route("api/auth")]
public class AuthController(RaceDayContext db) : ControllerBase
{
 [HttpPost("register"),ProducesResponseType(201),ProducesResponseType(400),ProducesResponseType(409)]
 public async Task<IActionResult> Register(RegisterRequest request){if(request.Role is not ("Organiser" or "Participant"))return BadRequest(new{message="Role must be Organiser or Participant."});var email=request.Email.Trim().ToLowerInvariant();if(await db.Users.AnyAsync(x=>x.Email==email))return Conflict(new{message="Email already registered."});var user=new User{FirstName=request.FirstName.Trim(),LastName=request.LastName.Trim(),Email=email,Role=request.Role,Phone=request.Phone};user.PasswordHash=new PasswordHasher<User>().HashPassword(user,request.Password);db.Users.Add(user);await db.SaveChangesAsync();return Created("/api/users/me",new{user.UserID,user.FirstName,user.LastName,user.Email,user.Role,user.Phone});}
 [HttpPost("login"),ProducesResponseType(200),ProducesResponseType(401)]
 public async Task<IActionResult> Login(LoginRequest request){var user=await db.Users.SingleOrDefaultAsync(x=>x.Email==request.Email.Trim().ToLowerInvariant());if(user is null||new PasswordHasher<User>().VerifyHashedPassword(user,user.PasswordHash,request.Password)==PasswordVerificationResult.Failed)return Unauthorized(new{message="Invalid email or password."});HttpContext.Session.SetInt32("UserID",user.UserID);HttpContext.Session.SetString("Role",user.Role);return Ok(new{message="Login successful",userId=user.UserID,role=user.Role});}
 [HttpPost("logout")] public IActionResult Logout(){HttpContext.Session.Clear();return Ok(new{message="Logout successful."});}
}
