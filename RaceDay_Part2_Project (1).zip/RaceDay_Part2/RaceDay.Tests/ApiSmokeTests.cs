using System.Net;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using RaceDay.Api.Data;
using Xunit;
namespace RaceDay.Tests;
public class ApiSmokeTests : IClassFixture<WebApplicationFactory<Program>>
{
 private readonly HttpClient _client;
 public ApiSmokeTests(WebApplicationFactory<Program> factory)
 {
  var app=factory.WithWebHostBuilder(builder=>{
   builder.UseEnvironment("Development");
   builder.ConfigureServices(services=>{
    services.RemoveAll<DbContextOptions<RaceDayContext>>();
    services.RemoveAll<IDbContextOptionsConfiguration<RaceDayContext>>();
    services.RemoveAll<RaceDayContext>();
    services.AddDbContext<RaceDayContext>(options=>options.UseInMemoryDatabase("RaceDayTests_"+Guid.NewGuid()));
   });
  });
  _client=app.CreateClient(new WebApplicationFactoryClientOptions { HandleCookies=true });
 }
 [Fact] public async Task EventsEndpoint_IsPublic(){var response=await _client.GetAsync("/api/events");Assert.Equal(HttpStatusCode.OK,response.StatusCode);}
 [Fact] public async Task ProfileEndpoint_RejectsUnauthenticatedRequest(){var response=await _client.GetAsync("/api/users/me");Assert.Equal(HttpStatusCode.Unauthorized,response.StatusCode);}
 [Fact] public async Task ParticipantOnlyEndpoint_RejectsUnauthenticatedRequest(){var response=await _client.GetAsync("/api/enrolments/me");Assert.Equal(HttpStatusCode.Unauthorized,response.StatusCode);}
 [Fact] public async Task OrganiserOnlyEndpoint_RejectsUnauthenticatedRequest(){var response=await _client.PostAsJsonAsync("/api/events",new {eventName="Test",eventType="Running",description="Test event",eventDate="2026-12-01",startTime="06:30:00",location="Cape Town"});Assert.Equal(HttpStatusCode.Unauthorized,response.StatusCode);}
}
